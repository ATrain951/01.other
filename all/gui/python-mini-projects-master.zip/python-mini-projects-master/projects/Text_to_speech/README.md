# txtToSpeech.py

When executed the text from abc.txt will be turned into an mp3, saved and then played on your device.

### Prerequisites
- abc.txt with your text
- the gTTS==2.1.1 module (pip install gTTS to download)
- the os module (pip install os)

### How to run the script
Write your desired text into the abc.txt file
then execute the txtToSpeech.py file. This can be 
done by typing 'python txtToSpeech.py' into your Terminal.


## *Author Name*
[Sergej Dikun](https://github.com/Serhazor)
