# Tic Tac Toe

## Description

A python based 2-player Tic Tac Toe game.
It takes input of the two players.
The two players are named as X and O
and will enter alternating moves in attempt to win the game.

## Prerequisites

Use any Python online compiler of download python IDE from https://www.python.org/

## How to run

Just run

```sh
python tic_tac_toe.py
```

<!-- ## Screenshots/Demo -->

## Authors
- [Erfan Saberi](https://github.com/erfansaberi)
- [Austin Jackson](https://github.com/vesche)