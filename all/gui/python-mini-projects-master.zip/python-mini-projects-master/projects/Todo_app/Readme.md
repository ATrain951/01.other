# Todo App using flask
## Perform Operation like
1. Add Task
2. Delete Task
3. Update Task

# To run app
- Create virtual Environment
- Install requirements
`pip install requirements.txt`
- run app
`py app.py`
