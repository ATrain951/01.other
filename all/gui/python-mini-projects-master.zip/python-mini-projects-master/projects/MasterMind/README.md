#100LinesOfCode
-----------------------------

**MASTERMIND GAME**

The Python program uses tkinter interface to create a GUI-based simulation of the MasterMind game.

Refer to the link to understand the rules of the game:
https://www.wikihow.com/Play-Mastermind

System Specifications: python3.8, Ubuntu 20.04

Dependencies: tkinter (*$ sudo apt-get install python3-tk*)  

![Mastermind](https://user-images.githubusercontent.com/48058736/130399281-0d43b5d3-82b7-4ad1-97d9-3dd71e60aa7c.png)

## Author Name
[Akshaya Visvanathan](https://github.com/aksvisu)