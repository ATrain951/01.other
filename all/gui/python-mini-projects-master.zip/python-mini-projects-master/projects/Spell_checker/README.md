# Script Title
<!--Remove the below lines and add yours -->
Here, you can input any word and check if it is having a correct spelling or not.

### Prerequisites
<!--Remove the below lines and add yours -->
First thing which you need to install is textblob library
<!--Install library-->
>pip install textblob
<!--For jupyter nb-->
You need to run this command in your terminal or your ide terminal.
<!--for jp nb-->
If you are using Jupyter Notebook you need to use the below command
<!--for jp nb-->
>import sys 
<!--command-->
>!{sys.executable} -m pip install textblob 

### How to run the script
<!--Remove the below lines and add yours -->
You can first install the textblob library and then you can run the python script.

## *Author Name*
<!--Remove the below lines and add yours -->
[Hariom1509](https://github.com/Hariom1509)
