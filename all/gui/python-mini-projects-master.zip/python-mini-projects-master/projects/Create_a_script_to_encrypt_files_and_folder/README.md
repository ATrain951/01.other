## create script to encrypt files and folder

### usage

python encrypt.py path(file or folder)

examples:
    python encrypt.py test.txt(file)
    or
    python eccrypt.py ./testdir(folder)

encrypted files("original_file_name.bin") will be generated in original location after the program running
