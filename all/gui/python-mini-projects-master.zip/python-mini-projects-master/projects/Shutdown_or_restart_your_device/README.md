# Power Options
<!--Remove the below lines and add yours -->
This script shuts down or restarts your computer

### Prerequisites
<!--Remove the below lines and add yours -->
None

### How to run the script
<!--Remove the below lines and add yours -->
Steps on how to run the script along with suitable examples.
1. Type the following on the command line:
python PowerOptions.py

2. Press enter and wait for prompt. Type “r” to restart or “s” to shut down

Example:
python PowerOptions.py 
Use 'r' for restart and 's' for shutdown: r

### Screenshot/GIF showing the sample use of the script
<!--Remove the below lines and add yours -->
python PowerOptions.py
Use 'r' for restart and 's' for shutdown: r

## *Author Name*
<!--Remove the below lines and add yours -->
[Phillibob55](https://github.com/Phillibob55)

