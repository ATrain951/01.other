# Dictionary to Python Object
<!--Remove the below lines and add yours -->
A Class in python to convert dictionary to a object

### Prerequisites
<!--Remove the below lines and add yours -->
None, only a running Python installation is required.

### How to run the script
<!--Remove the below lines and add yours -->
- Add the `class obj` in your code.
- Modify the code according to your need or use it directly:
  `ob = obj({'a':1, 'b': 2, 'c':3})`

## *Author Name*
<!--Remove the below lines and add yours -->
[Varun-22](https://github.com/Varun-22)
