## Script Title
This project contains a simple python script to play terminal-based hangman game.

## Prerequisites
None

## How to run the script
- Run the hangman.py script.
- Start to guess the word.

## Author Name
[Neoh Boon Yee](https://github.com/neohboonyee99)
