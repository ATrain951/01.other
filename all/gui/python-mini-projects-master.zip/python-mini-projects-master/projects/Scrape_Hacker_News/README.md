Scrape News From HackerNews website

A script that scrapes a number of pages from HackerNews


### How to run the script
In command go to the file directory, and "run python main.py" in commandline


## *Author Name*
[Javokhirbek](https://github.com/leader2one)
