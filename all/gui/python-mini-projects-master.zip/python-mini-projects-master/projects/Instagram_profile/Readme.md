## Instgram profile information

### install packages 
```
pip install -r requirements.txt
```

### Execute Program
```
python InstgramProfile.py <username>
```

### Sample run 


<img src="output.png"/>
