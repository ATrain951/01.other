## Script to organize files in a directory (alphabetical order)

### usage

```python
python main.py
```

Folder will be generated and files will be moved accordingly.
