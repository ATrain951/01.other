#Telegram bot

This is a demo project of a telegram bot

## Dependencies

```
pip install requirements.txt
```

## Search telegram to test the bot

```
@Bottest_bot_bot_bot_bot
```

## Start the program

```
python ./main.py
```

## Author Name

[Alexander Monterrosa](https://github.com/Alex108-lab)
