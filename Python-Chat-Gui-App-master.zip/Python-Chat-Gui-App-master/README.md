 
[![JoeVenner](https://badgen.net/badge/Developer/joeVenner/blue?icon=github)](https://github.com/joeVenner/)<br>
A simple Python Real Time Chat Application with GUI interface 
-
### GUI Interface : 

![Gui APP](https://i.ibb.co/vdvnyJn/cl1.png)

### How To use : 

 1. First clone the project repo from [Here](https://github.com/joeVenner/Python-Chat-Gui-App) 
 
 2. Run server file `python server.py`
    
![server](https://i.ibb.co/kSkn8jS/server.png)
 
 3. Run client file  `python client.py` you can run it as much as clients you want
	
![client 1](https://i.ibb.co/y8MwTwL/cl3.png)

![client2](https://i.ibb.co/MNhHMsv/client2.png)


<br><br>

Made By ❤ : [JoeVenner](mailto:ylafrimi@gmail.com)<br>
**Free Software, Hell Yeah!**

  

	 

  

